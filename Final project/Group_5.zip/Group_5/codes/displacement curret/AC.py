from manim import *
import numpy as np

class ACInductionFinalComplete(Scene):
    def construct(self):
        self.camera.background_color = "#0b132b"
        
        # ---------- Title ----------
        title = Text("Alternative Current Flow & Induction", 
                    color=YELLOW, 
                    font_size=24,
                    font="Arial Black")
        title.to_edge(UP)
        self.add(title)
        
        # 1. Phase control
        phase = ValueTracker(0)
        
        # 2. Capacitor dimensions and circuit
        offset_vec = LEFT * 1.5
        left_p = Rectangle(height=2.5, width=0.3, fill_color=YELLOW, fill_opacity=0.6).shift(LEFT*1.4 + offset_vec)
        right_p = Rectangle(height=2.5, width=0.3, fill_color=YELLOW, fill_opacity=0.6).shift(RIGHT*1.4 + offset_vec)
        
        # Wires (full path drawing)
        l_wire = Line(left_p.get_left() + LEFT*1.5, left_p.get_left(), color=GRAY)
        r_wire = Line(right_p.get_right(), right_p.get_right() + RIGHT*1.5, color=GRAY)
        l_vert = Line(l_wire.get_start(), l_wire.get_start() + DOWN*2, color=GRAY)
        r_vert = Line(r_wire.get_end(), r_wire.get_end() + DOWN*2, color=GRAY)
        b_wire = Line(l_vert.get_end(), r_vert.get_end(), color=GRAY)
        
        source = VGroup(
            Circle(radius=0.35, color=WHITE, fill_color="#0b132b", fill_opacity=1),
            FunctionGraph(lambda x: 0.1 * np.sin(2 * PI * x / 0.3), x_range=[-0.15, 0.15], color=WHITE)
        ).move_to(b_wire.get_center())
        
        self.add(left_p, right_p, l_wire, r_wire, l_vert, r_vert, b_wire, source)

        # 3. Field arrows (changing thickness and opacity)
        field_arrows = VGroup()
        for i in range(8):
            y = -1.1 + (i / 7) * 2.2
            arrow = always_redraw(lambda y=y: Arrow(
                start=right_p.get_left() + UP*y if np.sin(phase.get_value()) >= 0 else left_p.get_right() + UP*y,
                end=left_p.get_right() + UP*y if np.sin(phase.get_value()) >= 0 else right_p.get_left() + UP*y,
                color="#EC7063",
                stroke_width=abs(np.sin(phase.get_value())) * 12,
                fill_opacity=abs(np.sin(phase.get_value())),
                buff=0.1,
                max_tip_length_to_length_ratio=0.12
            ))
            field_arrows.add(arrow)
        self.add(field_arrows)

        # 4. Dipoles (expansion and contraction: blue for positive, red for negative)
        dipoles = VGroup()
        for i in range(5):
            y_pos = -1 + i * 0.5
            d = always_redraw(lambda y=y_pos: VGroup(
                Line(LEFT*0.25, RIGHT*0.25, color=YELLOW, stroke_width=2),
                Dot(RIGHT*0.25, radius=0.07, color=BLUE),  # Positive (+)
                Dot(LEFT*0.25, radius=0.07, color=RED),    # Negative (-)
            ).scale(np.sin(phase.get_value())).move_to(offset_vec + UP*y))
            dipoles.add(d)
        self.add(dipoles)

        # 5. Activating current movement (orange dots)
        # Define movement path for dots
        path_pts = [
            left_p.get_center(), l_wire.get_start(), 
            l_vert.get_end(), r_vert.get_end(), 
            r_wire.get_end(), right_p.get_center()
        ]
        current_path = VMobject().set_points_as_corners(path_pts)
        
        charges = VGroup(*[Dot(radius=0.06, color=ORANGE) for _ in range(15)])
        
        def update_charges(m):
            p = phase.get_value()
            # Current I = dQ/dt, so if voltage is sin then it follows cos
            current_intensity = np.cos(p) 
            for i, dot in enumerate(m):
                # Distribute dots along the path and oscillate them
                base_pos = (i / 15)
                oscillation = 0.15 * np.sin(p)
                pos = (base_pos + oscillation) % 1
                dot.move_to(current_path.point_from_proportion(pos))
                # Dots become more transparent when current decreases
                dot.set_opacity(abs(current_intensity))

        charges.add_updater(update_charges)
        self.add(charges)
        
        # ---------- Explanations on the right side ----------
        # Position for explanations
        explanation_pos = RIGHT * 4 + UP * 1.5
        
        # First explanation
        explanation1 = Text("1) The electric field continuously\nchanges in magnitude and direction.",
                          color=WHITE, 
                          font_size=18,
                          line_spacing=1.2,
                          should_center=False,
                          font="Arial Black")
        explanation1.move_to(explanation_pos)
        
        # Second explanation
        explanation2 = Text("2) Dipoles keep oscillating,\ncreating a continuous\ndisplacement current.",
                          color=WHITE, 
                          font_size=18,
                          line_spacing=1.2,
                          should_center=False,
                          font="Arial Black")
        explanation2.move_to(explanation_pos + DOWN * 1.2)
        
        # Third explanation
        explanation3 = Text("3) Displacement current depends on\nthe change of the field:",
                          color=WHITE, 
                          font_size=18,
                          line_spacing=1.2,
                          should_center=False,
                          font="Arial Black")
        explanation3.move_to(explanation_pos + DOWN * 2.4)
        
        # Formula
        formula = MathTex("I_d = \\varepsilon_0 \\frac{d\\Phi_E}{dt}",
                         color=YELLOW,
                         font_size=28)
        formula.move_to(explanation_pos + DOWN * 3.2)
        
        # Fourth explanation_ removed
        explanation4 = Text(" ",
                          color=WHITE, 
                          font_size=20,
                          line_spacing=1.2,
                          should_center=False,
                          font="Arial Black")
        explanation4.move_to(explanation_pos + DOWN * 4.0)

        # Add all explanations to a group
        explanations = VGroup(explanation1, explanation2, explanation3, formula, explanation4)
        
        # Start animation
        self.wait(1)
        
        # First animation phase: Show first explanation while starting the field movement
        self.play(
            Write(explanation1),
            phase.animate.set_value(0.5 * PI),
            run_time=2
        )
        
        # Second animation phase: Show second explanation
        self.play(
            Write(explanation2),
            phase.animate.set_value(PI),
            run_time=2
        )
        
        # Third animation phase: Show third explanation
        self.play(
            Write(explanation3),
            phase.animate.set_value(1.5 * PI),
            run_time=2
        )
        
        # Fourth animation phase: Show formula
        self.play(
            Write(formula),
            phase.animate.set_value(2 * PI),
            run_time=2
        )
        
        # Fifth animation phase: Show fourth explanation and continue animation
        self.play(
            Write(explanation4),
            phase.animate.set_value(4 * PI),
            run_time=4
        )
        
        self.wait(2)