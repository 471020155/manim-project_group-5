from manim import *
import numpy as np

# ---------- Colors & Style ----------
BACKGROUND_COLOR = "#0b132b"
FIELD_COLOR = RED  # Changed from GREEN to RED
FIELD_WEAK = "#FF6B6B"   # Lighter Red for weak field
POS_COLOR = "#E74C3C"    # Red
NEG_COLOR = "#3498DB"    # Blue
DIELECTRIC_COLOR = GRAY

class CompactHorizontalCapacitorRed(Scene):
    def construct(self):
        self.camera.background_color = BACKGROUND_COLOR

        # 1. LAYOUT SETUP
        divider = Line(UP*4, DOWN*4, color=GRAY)
        self.add(divider)

        # Labels: 1st Line Red, 2nd Line Yellow
        title_e = Text("The E-Field", font_size=24, color=FIELD_COLOR).to_corner(UL).shift(RIGHT*0.5)
        text_e = Text("Affected by Bound Charges", font_size=18, color=YELLOW).next_to(title_e, DOWN, aligned_edge=LEFT)
        
        title_d = Text("The D-Field", font_size=24, color=FIELD_COLOR).to_corner(UR).shift(LEFT*0.5)
        text_d = Text("Independent of Material", font_size=18, color=YELLOW).next_to(title_d, DOWN, aligned_edge=RIGHT)
        
        self.add(title_e, text_e, title_d, text_d)

        # Dimensions (Plates are now closer)
        block_width = 3.2
        slab_height = 1.4
        plate_offset = 1.1 # Reduced from 2.2 to bring them closer
        num_cols = 12

        # ==========================================================
        # LEFT SIDE: E-FIELD
        # ==========================================================
        center_L = LEFT * 3.5
        
        # Plates (Close together)
        p_plate_L = Rectangle(width=block_width, height=0.2, fill_opacity=1, color=POS_COLOR).shift(center_L + UP*plate_offset)
        n_plate_L = Rectangle(width=block_width, height=0.2, fill_opacity=1, color=NEG_COLOR).shift(center_L + DOWN*plate_offset)
        
        # Dielectric Slab
        slab_L = Rectangle(width=block_width, height=slab_height, fill_opacity=0.3, color=DIELECTRIC_COLOR).shift(center_L)
        self.add(p_plate_L, n_plate_L, slab_L)

        e_elements = VGroup()
        for i, x in enumerate(np.linspace(-1.4, 1.4, num_cols)):
            top_y, interface_T, interface_B, bot_y = plate_offset - 0.1, 0.7, -0.7, -(plate_offset - 0.1)
            
            # --- 1. Air (Top - Strong) ---
            e_elements.add(Line(center_L + RIGHT*x + UP*top_y, center_L + RIGHT*x + UP*interface_T, 
                                color=FIELD_COLOR, stroke_width=4))

            # --- 2. Reflection (Red) ---
            if i % 3 == 0:
                refl_start = center_L + RIGHT*x + UP*interface_T
                refl_end = refl_start + UP*0.2 + RIGHT*0.1
                e_elements.add(Arrow(refl_start, refl_end, color=FIELD_COLOR, stroke_width=2, tip_length=0.08, buff=0))

            # --- 3. Inside (Attenuation & Bending) ---
            if i % 1.5 < 1:
                bend_x = x * 0.9 
                e_elements.add(Line(center_L + RIGHT*x + UP*interface_T, center_L + RIGHT*bend_x + UP*interface_B, 
                                   color=FIELD_WEAK, stroke_width=2))
                
                # --- 4. Air (Bottom - Strong) ---
                e_elements.add(Arrow(center_L + RIGHT*bend_x + UP*interface_B, center_L + RIGHT*bend_x + UP*bot_y, 
                                     color=FIELD_COLOR, stroke_width=4, tip_length=0.15, buff=0))

        # Polarization Sheets
        bound_charges = VGroup()
        for x in np.linspace(-1.4, 1.4, 10):
            n_dot = Dot(center_L + RIGHT*x + UP*0.55, radius=0.07, color=NEG_COLOR)
            n_sign = Text("-", font_size=14, weight=BOLD, color=WHITE).move_to(n_dot)
            p_dot = Dot(center_L + RIGHT*x + DOWN*0.55, radius=0.07, color=POS_COLOR)
            p_sign = Text("+", font_size=10, weight=BOLD, color=WHITE).move_to(p_dot)
            bound_charges.add(VGroup(n_dot, n_sign, p_dot, p_sign))

        self.play(Create(e_elements), FadeIn(bound_charges, lag_ratio=0.05), run_time=2.5)

        # ==========================================================
        # RIGHT SIDE: D-FIELD
        # ==========================================================
        center_R = RIGHT * 3.5
        
        p_plate_R = p_plate_L.copy().move_to(center_R + UP*plate_offset)
        n_plate_R = n_plate_L.copy().move_to(center_R + DOWN*plate_offset)
        slab_R = slab_L.copy().move_to(center_R)
        self.add(p_plate_R, n_plate_R, slab_R)

        d_lines = VGroup()
        for x in np.linspace(-1.4, 1.4, num_cols):
            # Straight Red arrows ignoring the gap and slab
            d_lines.add(Arrow(center_R + RIGHT*x + UP*(plate_offset-0.1), 
                              center_R + RIGHT*x + DOWN*(plate_offset-0.1), 
                              color=FIELD_COLOR, stroke_width=4, tip_length=0.2, buff=0))

        self.play(Create(d_lines), run_time=1.5)
        self.wait(5)