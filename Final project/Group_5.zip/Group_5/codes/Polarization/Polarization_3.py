from manim import *

BACKGROUND_COLOR = "#0b132b"
TEXT_COLOR = WHITE
NEGATIVE_COLOR = "#5DADE2"
POSITIVE_COLOR = "#EC7063"
ATOM_OUTLINE_COLOR = WHITE
FIELD_COLOR = RED

SIGN_FONT_SIZE = 25
TEXT_FONT_SIZE = 28

class LowerPartOnly(Scene):
    def construct(self):
        self.camera.background_color = BACKGROUND_COLOR

        atom_radius = 0.7

        # Text lines - start from top
        line1 = Text("Applying electric field (E),", font_size=TEXT_FONT_SIZE, color=TEXT_COLOR, font="Arial")\
            .to_edge(UP).shift(DOWN * 0.9)  # Move down more
        
        line2 = Text("the material starts to", font_size=TEXT_FONT_SIZE, color=TEXT_COLOR, font="Arial")\
            .next_to(line1, DOWN, buff=0.3)
        
        line3 = Text("POLARIZE (stretching)", font_size=TEXT_FONT_SIZE, color=TEXT_COLOR, font="Arial")\
            .next_to(line2, DOWN, buff=0.3)
        
        line4 = Text("and it represents the material's ability", font_size=TEXT_FONT_SIZE, color=TEXT_COLOR, font="Arial")\
            .next_to(line3, DOWN, buff=0.3)
        
        line5 = Text("to store electric field, called", font_size=TEXT_FONT_SIZE, color=TEXT_COLOR, font="Arial")\
            .next_to(line4, DOWN, buff=0.3)
        
        # "permittivity ε" in larger font size on its own line
        line6_part1 = Text("permittivity", font_size=TEXT_FONT_SIZE + 6, color=YELLOW, font="Times New Roman")
        line6_part2 = Text(" ε", font_size=TEXT_FONT_SIZE + 6, color=YELLOW, font="Times New Roman")
        
        line6 = VGroup(line6_part1, line6_part2).arrange(RIGHT, buff=0.05)\
            .next_to(line5, DOWN, buff=0.4)

        text_group = VGroup(line1, line2, line3, line4, line5, line6)

        # Move text to right side after showing from top
        self.play(FadeIn(text_group))
        self.wait(0.5)
        
        self.play(
            text_group.animate.to_edge(RIGHT).shift(DOWN * 0.1 + LEFT * 0.4),  # Down instead of up
            run_time=0.8
        )

        # Atom outline
        atom_outline = Circle(radius=atom_radius, stroke_width=3, color=ATOM_OUTLINE_COLOR)

        # Charge regions
        negative_fill = Sector(
            radius=atom_radius - 0.03,
            start_angle=PI / 2,
            angle=PI,
            color=NEGATIVE_COLOR,
            fill_opacity=1,
            stroke_width=0
        )

        positive_fill = Sector(
            radius=atom_radius - 0.03,
            start_angle=-PI / 2,
            angle=PI,
            color=POSITIVE_COLOR,
            fill_opacity=1,
            stroke_width=0
        )

        # Charge signs
        negative_sign = Text("-", font_size=SIGN_FONT_SIZE, color=TEXT_COLOR).shift(LEFT * 0.25)
        positive_sign = Text("+", font_size=SIGN_FONT_SIZE, color=TEXT_COLOR).shift(RIGHT * 0.25)

        # Atom position
        atom_center = LEFT * 3 + DOWN * 0.3

        atom_group = VGroup(
            atom_outline,
            negative_fill,
            positive_fill,
            negative_sign,
            positive_sign
        ).move_to(atom_center)

        self.play(FadeIn(atom_group))

        # Electric field arrows
        arrows = VGroup()
        x_start = -6
        x_end = -1
        y_base = atom_center[1] - 1.2

        for i in range(4):
            y = y_base + i * 0.7
            arrow = Arrow(
                start=[x_start, y, 0],
                end=[x_end, y, 0],
                color=FIELD_COLOR,
                stroke_width=5,
                buff=0,
                tip_length=0.2
            )
            arrows.add(arrow)

        self.play(*[GrowArrow(a) for a in arrows], run_time=2)
        self.wait(0.5)

        # Deformed atom shape
        ellipse_outline = Ellipse(
            width=2.55,
            height=1.35,
            color=ATOM_OUTLINE_COLOR,
            stroke_width=3
        ).move_to(atom_center)

        negative_fill_ellipse = negative_fill.copy().stretch(2, 0).shift(LEFT * 0.6)
        positive_fill_ellipse = positive_fill.copy().stretch(2, 0).shift(RIGHT * 0.6)

        negative_sign_ellipse = negative_sign.copy().shift(LEFT * 0.6)
        positive_sign_ellipse = positive_sign.copy().shift(RIGHT * 0.6)

        negative_fill_ellipse.move_to(atom_center + LEFT * 0.6)
        positive_fill_ellipse.move_to(atom_center + RIGHT * 0.6)
        negative_sign_ellipse.move_to(atom_center + LEFT * 0.6)
        positive_sign_ellipse.move_to(atom_center + RIGHT * 0.6)

        self.play(
            ReplacementTransform(atom_outline, ellipse_outline),
            ReplacementTransform(negative_fill, negative_fill_ellipse),
            ReplacementTransform(positive_fill, positive_fill_ellipse),
            ReplacementTransform(negative_sign, negative_sign_ellipse),
            ReplacementTransform(positive_sign, positive_sign_ellipse),
            run_time=1.5
        )

        self.wait(3)