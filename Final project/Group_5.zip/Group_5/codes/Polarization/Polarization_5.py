from manim import *

BACKGROUND_COLOR = "#0b132b"
TEXT_COLOR = WHITE
NEGATIVE_COLOR = "#5DADE2"
POSITIVE_COLOR = "#EC7063"
ATOM_OUTLINE_COLOR = WHITE
FIELD_COLOR = RED
INTERNAL_FIELD_COLOR = YELLOW

SIGN_FONT_SIZE = 25
TEXT_FONT_SIZE = 28
SPHERE_RADIUS = 0.2

class LowerPartOnly(Scene):
    def construct(self):
        self.camera.background_color = BACKGROUND_COLOR

        atom_radius = 0.7
        separation_gap = 0.25

        main_title = Text(
            "(1) Electronic Polarization",
            font_size=50,  
            color=TEXT_COLOR,
            font="Times New Roman"
        ).to_edge(UP).to_edge(LEFT)  

        self.play(Write(main_title))
        self.wait(0.5)

        text_main = Text(
            "When an insulating material atom\nis exposed to an external field,\nstretching occurs leading to\npolarization phenomenon",
            font_size=TEXT_FONT_SIZE - 2,
            color=TEXT_COLOR,
            line_spacing=0.8
        ).to_edge(RIGHT).shift(DOWN * 0.5) 

        self.play(FadeIn(text_main))
        self.wait(0.5)

        overall_shift = LEFT * 3.5  
        vertical_shift = UP * 0.5  
        
        atom_center = ORIGIN + overall_shift + vertical_shift
        atom_outline = Circle(
            radius=atom_radius, 
            stroke_width=3, 
            color=ATOM_OUTLINE_COLOR
        ).move_to(atom_center)

        negative_sphere = Circle(
            radius=SPHERE_RADIUS,
            color=NEGATIVE_COLOR,
            fill_color=NEGATIVE_COLOR,
            fill_opacity=1,
            stroke_width=2
        ).move_to(atom_center + LEFT * (separation_gap/2))

        negative_sign = Text("-", font_size=SIGN_FONT_SIZE, color=BACKGROUND_COLOR).move_to(negative_sphere.get_center())

        positive_sphere = Circle(
            radius=SPHERE_RADIUS,
            color=POSITIVE_COLOR,
            fill_color=POSITIVE_COLOR,
            fill_opacity=1,
            stroke_width=2
        ).move_to(atom_center + RIGHT * (separation_gap/2))

        positive_sign = Text("+", font_size=SIGN_FONT_SIZE, color=BACKGROUND_COLOR).move_to(positive_sphere.get_center())

        original_atom = VGroup(
            atom_outline,
            negative_sphere,
            positive_sphere,
            negative_sign,
            positive_sign
        )

        self.play(FadeIn(original_atom))
        self.wait(1)

        arrows = VGroup()
        
        x_start = -2.5 + overall_shift[0]  
        x_end = 2.5 + overall_shift[0]    
        y_base = atom_center[1]
        
        vertical_offset = -1.2
        
        for i in range(4):
            y = y_base + vertical_offset + i * 0.65
            arrow = Arrow(
                start=[x_start, y, 0],
                end=[x_end, y, 0],
                color=FIELD_COLOR,
                stroke_width=5,
                buff=0,
                tip_length=0.2
            )
            arrows.add(arrow)

        external_field_label = Text("E_ext", font_size=24, color=FIELD_COLOR)
        external_field_label.next_to(arrows[2], RIGHT, buff=0.5).shift(UP * 0.1)

        self.play(*[GrowArrow(a) for a in arrows], Write(external_field_label), run_time=2)
        self.wait(0.5)

        ellipse_width = 2.2
        ellipse_height = 1.4
        
        ellipse_outline = Ellipse(
            width=ellipse_width,
            height=ellipse_height,
            color=ATOM_OUTLINE_COLOR,
            stroke_width=3
        ).move_to(atom_center)
        
        margin = 0.3
        max_x_position = ellipse_width/2 - SPHERE_RADIUS - margin
        
        negative_sphere_new = Circle(
            radius=SPHERE_RADIUS,
            color=NEGATIVE_COLOR,
            fill_color=NEGATIVE_COLOR,
            fill_opacity=1,
            stroke_width=2
        ).move_to(ellipse_outline.get_center() + LEFT * (max_x_position * 0.9))
        
        negative_sign_new = Text("-", font_size=SIGN_FONT_SIZE, color=BACKGROUND_COLOR).move_to(negative_sphere_new.get_center())
        
        positive_sphere_new = Circle(
            radius=SPHERE_RADIUS,
            color=POSITIVE_COLOR,
            fill_color=POSITIVE_COLOR,
            fill_opacity=1,
            stroke_width=2
        ).move_to(ellipse_outline.get_center() + RIGHT * (max_x_position * 0.9))
        
        positive_sign_new = Text("+", font_size=SIGN_FONT_SIZE, color=BACKGROUND_COLOR).move_to(positive_sphere_new.get_center())
        
        self.play(
            ReplacementTransform(atom_outline, ellipse_outline),
            ReplacementTransform(negative_sphere, negative_sphere_new),
            ReplacementTransform(positive_sphere, positive_sphere_new),
            ReplacementTransform(negative_sign, negative_sign_new),
            ReplacementTransform(positive_sign, positive_sign_new),
            run_time=1.5
        )

        self.wait(1)
        
        ellipse_background = Ellipse(
            width=ellipse_width - 0.15,
            height=ellipse_height - 0.15,
            color=ATOM_OUTLINE_COLOR,
            fill_color=ATOM_OUTLINE_COLOR,
            fill_opacity=0.06,
            stroke_width=0
        ).move_to(ellipse_outline.get_center())
        
        self.play(FadeIn(ellipse_background))
        
        yellow_arrow_start = positive_sphere_new.get_center() + LEFT * SPHERE_RADIUS * 0.9
        yellow_arrow_end = negative_sphere_new.get_center() + RIGHT * SPHERE_RADIUS * 0.9
        
        yellow_arrow = Arrow(
            start=yellow_arrow_start,
            end=yellow_arrow_end,
            color=INTERNAL_FIELD_COLOR,
            stroke_width=4,
            buff=0,
            tip_length=0.15
        )
        
        yellow_arrow_label = Text("E_int", font_size=20, color=INTERNAL_FIELD_COLOR)
        yellow_arrow_label.next_to(yellow_arrow, UP, buff=0.1)
        
        self.play(
            Create(yellow_arrow),
            Write(yellow_arrow_label),
            run_time=1
        )
        
        self.wait(1.5)
        
        dipole_group = VGroup(
            ellipse_outline,
            ellipse_background,
            negative_sphere_new,
            positive_sphere_new,
            negative_sign_new,
            positive_sign_new,
            yellow_arrow,
            yellow_arrow_label
        )
        
        self.play(
            dipole_group.animate.scale(1.05),
            run_time=0.5
        )
        self.play(
            dipole_group.animate.scale(1/1.05),
            run_time=0.5
        )
        
        self.wait(3)